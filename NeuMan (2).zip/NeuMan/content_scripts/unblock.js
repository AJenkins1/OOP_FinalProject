(function () {
  var overlay = document.getElementById('matchu-pomodoro-extension-overlay');
  document.body.removeChild(overlay);
})();
